// Function to remove elements with a class containing "Main_side"
//author: weibo@Coodmow
function removeMainSideDiv() {
    const elements = document.querySelectorAll('[class*="Main_side"]'); // Match elements where the class contains "Main_side"
    elements.forEach((el) => {
      console.log("Removing element with class containing 'Main_side':", el);
      el.remove(); // Remove the element from the DOM
    });
  }
  
  // Observe DOM changes for dynamically added elements
  const observer = new MutationObserver(() => {
    removeMainSideDiv();
  });
  observer.observe(document.body, { childList: true, subtree: true });
  
  // Initial cleanup for already-loaded elements
  removeMainSideDiv();
  